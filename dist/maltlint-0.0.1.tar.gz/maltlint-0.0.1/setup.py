# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'maltlint',
    'version': '0.0.1',
    'description': 'maltlint',
    'long_description': "# Linting according to Malte's preferences\nTODO: Give a short introduction of your project. Let this section explain the objectives or the motivation behind this project. \n\n# Getting Started\nTODO: Guide users through getting your code up and running on their own system. In this section you can talk about:\n1.\tInstallation process\n2.\tSoftware dependencies\n3.\tLatest releases\n4.\tAPI references\n\n# Build and Test\nTODO: Describe and show how to build your code and run the tests. \n\n# Contribute\nTODO: Explain how other users and developers can contribute to make your code better. \n\nIf you want to learn more about creating good readme files then refer the following [guidelines](https://docs.microsoft.com/en-us/azure/devops/repos/git/create-a-readme?view=azure-devops). You can also seek inspiration from the below readme files:\n- [ASP.NET Core](https://github.com/aspnet/Home)\n- [Visual Studio Code](https://github.com/Microsoft/vscode)\n- [Chakra Core](https://github.com/Microsoft/ChakraCore)\n",
    'author': 'Yes',
    'author_email': 'not@important.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
